import React from 'react';
import './UserPolicy.css';
const UserPolicy = () => {
    return (
        <div>
            <h2>This is user</h2>
        </div>
    );
};

export default UserPolicy;