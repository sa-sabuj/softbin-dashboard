import React from 'react';
import './News.css'

const News = () => {
    return (
        <div>
            <h2>this is news page</h2>
        </div>
    );
};

export default News;